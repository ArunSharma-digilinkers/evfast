@extends('layouts.app')

@section('content')
<h2>My Account</h2>
<p>View orders & profile</p>
@endsection
